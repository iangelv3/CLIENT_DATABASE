CREATE VIEW invoiceView 
AS SELECT concat(cl.firstName, " ", cl.lastName) AS Client, concat(co.firstName, " ", co.lastName)
AS Contractor, s.supplierName AS Supplier, m.description AS Material, m.cost AS Cost
FROM material m, supplier s, contractor co, client cl, invoice i, project p
WHERE i.projectId = p.Id
AND i.materialId = m.ID
AND p.clientId = cl.ID
AND p.contractorId = co.ID
AND m.supplierId = s.ID
ORDER BY Client;

INSERT INTO invoice (projectId, materialId) VALUES 

(2 , 7); 

(2 ,2); 

(2 , 7);  

1, 2 , Half wall shower glass 

Dane Kaiser Brian Roberts , 3 

Dane Kaiser Brian Roberts , 36 inch square sink                   

Dane Kaiser Brian Roberts , Large tub                             

Kavita Heath Haniya Kaiser , Bathroom sink faucet package with separate hotand cold handles 

Kavita Heath Haniya Kaiser , Shower faucet package with single hot and cold 

Kavita Heath Haniya Kaiser , 72 inch bathroom quartz counter top 

Kavita Heath Haniya Kaiser , 36 inch square sink 

Kavita Heath Haniya Kaiser , Medium tub 

Uzair Sparrow Victor Newman , 24 inch bathroom granite counter top 

Uzair Sparrow Victor Newman , Small bathroom paint package 