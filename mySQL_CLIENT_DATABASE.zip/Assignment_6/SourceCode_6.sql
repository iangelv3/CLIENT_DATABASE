INSERT INTO project (clientId, contractorId, startDate, estimatedEndDate) VALUES
(1,2, '2022-04-01', '2022-05-01'),
(2,2,  '2022-05-03', '2022-06-15'),
(4,2, '2022-06-16', '2022-08-01'),
(5,2, '2022-08-02', '2022-09-30'),
(10,8, '2022-10-01', '2022-11-30'),
(11,8, '2022-04-01', '2022-04-15'),
(12,8, '2022-04-16', '2022-05-16'),
(13,8, '2022-06-01', '2022-06-30'),
(14,8, '2022-07-06', '2022-08-25'),
(15,8, '2022-08-25', '2022-10-31');


SELECT concat(c.firstName, " ", c.lastName) AS contractor, s.supplierName AS Supplier
FROM contractor c, supplier s, contractorSupplier cs
WHERE cs.contractorId = c.Id
AND cs.supplierId = s.Id
ORDER BY Contractor, Supplier;

CREATE VIEW scheduleView AS
SELECT concat(c.firstName," ", c.lastName) AS Contractor, concat(cs.firstName," ", cs.lastName) AS Client, p.startDate AS Start, p.estimatedEndDate AS Completion
FROM contractor c, client cs, project p
WHERE c.id = p.contractorId
AND cs.id = p.clientId
ORDER BY Contractor, Start;